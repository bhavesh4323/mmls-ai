import requests, os, json, time
API='http://localhost:5000'
OUT=[]
# Streamlit
try:
    r=requests.get('http://localhost:8501', timeout=3)
    OUT.append(f"STREAMLIT: reachable (HTTP {r.status_code})")
except Exception as e:
    OUT.append(f"STREAMLIT: unreachable ({e})")
# Files
files=['feature_importance.png','lstm_actual.npy','lstm_preds.npy','lstm_hours.npy']
for f in files:
    OUT.append(f"FILE {f}: {'FOUND' if os.path.exists(f) else 'MISSING'}")
# QR codes
qr_count=0
if os.path.exists('qr_codes'):
    qr_count=len([x for x in os.listdir('qr_codes') if x.lower().endswith('.png')])
OUT.append(f"QR_CODES: {qr_count} PNG files in qr_codes/")
# Inventory
try:
    inv=requests.get(API+'/inventory', timeout=5).json()
    OUT.append(f"INVENTORY: {len(inv)} items")
except Exception as e:
    OUT.append(f"INVENTORY: error ({e})")
# Hours of supply
try:
    hos=requests.get(API+'/hours_of_supply', timeout=5).json()
    ok = isinstance(hos, list) and all('hours_of_supply' in i for i in hos)
    OUT.append(f"HOURS_OF_SUPPLY: {len(hos)} rows, structure_ok={ok}")
except Exception as e:
    OUT.append(f"HOURS_OF_SUPPLY: error ({e})")
# Forecast
try:
    f=requests.get(API+"/forecast?operational_tempo=0.8&t1=0.3&t2=0.2&t3=0.1", timeout=10).json()
    preds=f.get('predictions',[])
    OUT.append(f"FORECAST: {len(preds)} predictions, sample_keys={list(preds[0].keys()) if preds else []}")
except Exception as e:
    OUT.append(f"FORECAST: error ({e})")
# Audit log before
try:
    a_before=requests.get(API+'/audit_log', timeout=5).json()
    OUT.append(f"AUDIT_BEFORE: {len(a_before)} entries")
except Exception as e:
    OUT.append(f"AUDIT_BEFORE: error ({e})")
# Scan a controlled drug (ITM002) and check audit increases
try:
    r=requests.post(API+'/scan', json={'item_id':'ITM002','quantity_used':1,'user':'auto_test'}, timeout=5)
    OUT.append(f"SCAN ITM002: status={r.status_code}, resp_keys={list(r.json().keys()) if r.status_code==200 else 'ERR'}")
    a_after=requests.get(API+'/audit_log', timeout=5).json()
    OUT.append(f"AUDIT_AFTER: {len(a_after)} entries (delta={len(a_after)-len(a_before)})")
except Exception as e:
    OUT.append(f"SCAN: error ({e})")
# Duplicate register test
try:
    payload={'item_id':'ITM001','item_name':'Duplicate Test','expiry_days':30}
    r=requests.post(API+'/register_item', json=payload, timeout=5)
    OUT.append(f"DUP_REG: status={r.status_code}, resp={r.json() if r.status_code!=500 else r.text}")
except Exception as e:
    OUT.append(f"DUP_REG: error ({e})")
# Summary print
print('\n'.join(OUT))
