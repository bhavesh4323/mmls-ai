"""
train_model.py — MMLS-AI v2.0
Trains XGBoost on training_data.csv to predict consumption_rate.
"""

import pandas as pd
import numpy as np
from xgboost import XGBRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score, mean_squared_error
import joblib
import matplotlib.pyplot as plt

# 1. Load dataset
print("Loading dataset...")
# Make sure to use the exact CSV file name you have!
df = pd.read_csv("training_data (1).csv") 
print(f"Rows: {len(df)}  |  Columns: {len(df.columns)}")

# 2. Split features and target
y = df["consumption_rate"]

# CRITICAL FIX: Force the exact feature order that app.py uses for predictions!
feature_cols = [
    "item_encoded", 
    "echelon_encoded", 
    "operational_tempo",
    "casualty_mix_T1", 
    "casualty_mix_T2", 
    "casualty_mix_T3",
    "controlled_drug", 
    "current_stock", 
    "base_rate",
    "avg_temperature", 
    "resupply_lead_hours", 
    "days_to_expiry",
    "pack_type_encoded"
]

# Create X using strictly the ordered columns
X = df[feature_cols]

# 3. Train / test split 80/20
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)
print(f"Train rows: {len(X_train)}  |  Test rows: {len(X_test)}")

# 4. Train XGBoost
print("\nTraining XGBoost model...")
model = XGBRegressor(
    n_estimators=500,
    max_depth=8,
    learning_rate=0.05,
    subsample=0.8,
    colsample_bytree=0.8,
    random_state=42,
    verbosity=0
)
model.fit(X_train, y_train)

# 5. Evaluate
y_pred = model.predict(X_test)
r2  = r2_score(y_test, y_pred)
mse = mean_squared_error(y_test, y_pred)

print("\n" + "=" * 45)
print("         MODEL RESULTS")
print("=" * 45)
print(f"  R2 Score : {r2:.6f}")
print(f"  MSE      : {mse:.6f}")
print(f"  RMSE     : {mse**0.5:.6f}")
if r2 >= 0.99:
    print("  TARGET ACHIEVED  R2 >= 0.99")
else:
    print("  R2 below 0.99 target")
print("=" * 45)

# 6. Save model
joblib.dump(model, "model.pkl")
print("\nmodel.pkl saved")

# 7. Feature importance chart
feat_names = X.columns.tolist()
importances = model.feature_importances_

plt.figure(figsize=(8, 5))
sorted_idx = np.argsort(importances)
plt.barh(
    [feat_names[i] for i in sorted_idx],
    [importances[i] for i in sorted_idx],
    color="#378ADD"
)
plt.xlabel("Importance Score")
plt.title("XGBoost Feature Importance - MMLS-AI")
plt.tight_layout()
plt.savefig("feature_importance.png", dpi=150)
plt.close()
print("feature_importance.png saved")