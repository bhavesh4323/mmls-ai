"""
seed_database.py — MMLS-AI v2.0
Loads all 20 inventory items into MongoDB.

Put this in your mmsai folder and run:
    python seed_database.py
"""

from pymongo import MongoClient
from datetime import datetime, timedelta

# ── Connect to MongoDB ─────────────────────────────────────────────────────────
client =  MongoClient("mongodb+srv://bhaveshpal2672004_db_user:OxQLfgVpTmxPIufK@cluster0.nimtcxq.mongodb.net/?appName=Cluster0")
db     = client["mmls_ai"]
col    = db["inventory"]

# ── Clear existing data ────────────────────────────────────────────────────────
col.delete_many({})
print("Cleared existing inventory...")

# ── 20 items from Sheet 8 ─────────────────────────────────────────────────────
# Fields: item_id, item_name, category, echelon, controlled_drug,
#         current_stock, alert_threshold, avg_consumption_per_hour,
#         expiry_days, pack_type
today = datetime.today()

items = [
    ("ITM001", "Morphine 10mg/ml",   "Analgesic",    "Role1", True,  25,  10, 4.17,  180,  "Role1_Pack"),
    ("ITM002", "Ketamine 500mg",     "Anaesthetic",  "Role2", True,  10,  5,  2.08,  365,  "Role2_Pack"),
    ("ITM003", "Fentanyl 100mcg",    "Analgesic",    "Role1", True,  8,   5,  2.08,  90,   "Role1_Pack"),
    ("ITM004", "CAT Tourniquet",     "Haemostasis",  "Role1", False, 250, 10, 10.42, 3650, "Role1_Pack"),
    ("ITM005", "Chest Seal Vented",  "Thoracic",     "Role1", False, 250, 10, 10.42, 1825, "Role1_Pack"),
    ("ITM006", "TXA 1g/10ml",        "Haemostasis",  "Role1", False, 250, 10, 10.42, 730,  "Role1_Pack"),
    ("ITM007", "pRBC O-Negative",    "Transfusion",  "Role2", False, 90,  4,  1.25,  42,   "Role2_Pack"),
    ("ITM008", "IV Fluid 500ml",     "IV Therapy",   "Role1", False, 450, 15, 10.42, 1095, "Role1_Pack"),
    ("ITM009", "IV Cannula 18G",     "IV Access",    "Role1", False, 250, 20, 10.42, 1825, "Role1_Pack"),
    ("ITM010", "ETT Size 7.0",       "Airway",       "Role2", False, 250, 5,  10.42, 1825, "Role2_Pack"),
    ("ITM011", "Blood Giving Set",   "Transfusion",  "Role2", False, 150, 5,  1.25,  730,  "Role2_Pack"),
    ("ITM012", "Syringe 10ml",       "Equipment",    "Role1", False, 600, 25, 20.83, 1825, "Role1_Pack"),
    ("ITM013", "Syringe 2ml",        "Equipment",    "Role1", False, 600, 20, 20.83, 1825, "Role1_Pack"),
    ("ITM014", "Surgical Gloves",    "PPE",          "Role2", False, 300, 15, 4.17,  1095, "Role2_Pack"),
    ("ITM015", "Decomp Needle 14G",  "Thoracic",     "Role1", False, 150, 5,  2.08,  1095, "Role1_Pack"),
    ("ITM016", "Cric Kit",           "Airway",       "Role2", False, 150, 2,  2.08,  1825, "Role2_Pack"),
    ("ITM017", "QuikClot Dressing",  "Haemostasis",  "Role1", False, 750, 8,  10.42, 1095, "Role1_Pack"),
    ("ITM018", "Burn Dressing Lg",   "Burns",        "Role2", False, 200, 5,  2.78,  1095, "Burns_Pack"),
    ("ITM019", "Eye Shield",         "Trauma",       "Role1", False, 250, 5,  3.47,  1825, "Role1_Pack"),
    ("ITM020", "Sam Splint",         "Orthopaedic",  "Role1", False, 200, 5,  2.78,  3650, "Role1_Pack"),
]

docs = []
for item in items:
    item_id, name, category, echelon, controlled, stock, alert, consumption, expiry_days, pack = item
    docs.append({
        "item_id":                   item_id,
        "item_name":                 name,
        "category":                  category,
        "echelon":                   echelon,
        "controlled_drug":           controlled,
        "current_stock":             stock,
        "initial_stock":             stock,
        "alert_threshold":           alert,
        "avg_consumption_per_hour":  consumption,
        "expiry_date":               today + timedelta(days=expiry_days),
        "pack_type":                 pack,
        "last_updated":              today,
    })

col.insert_many(docs)

print("=" * 45)
print("  MMLS-AI — Database Seeded")
print("=" * 45)
print(f"  Items inserted : {col.count_documents({})}")
print(f"  Database       : mmls_ai")
print(f"  Collection     : inventory")
print()

# Print a summary of what was inserted
for doc in col.find({}, {"_id": 0, "item_id": 1, "item_name": 1, "current_stock": 1, "controlled_drug": 1}):
    ctrl = " [CONTROLLED]" if doc["controlled_drug"] else ""
    print(f"  {doc['item_id']}  {doc['item_name']:<22} stock: {doc['current_stock']}{ctrl}")

print()
print("  Ready for app.py")
print("=" * 45)
