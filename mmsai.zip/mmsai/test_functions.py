#!/usr/bin/env python3
"""
Function-level testing for MMLS-AI project
Tests individual functions from each module
"""

import sys
import traceback
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

print("=" * 80)
print("MMLS-AI FUNCTION-LEVEL TESTING")
print("=" * 80)
print()

# Test counter
tests_passed = 0
tests_failed = 0

def test_function(test_name, test_func):
    global tests_passed, tests_failed
    try:
        print(f"Testing: {test_name}...", end=" ")
        result = test_func()
        print(f"✓ PASS - {result}")
        tests_passed += 1
        return True
    except Exception as e:
        print(f"✗ FAIL")
        print(f"  Error: {e}")
        tests_failed += 1
        return False

print("1. UTILITY FUNCTIONS (from app.py)")
print("-" * 80)

# Test get_hos_tier function
def test_get_hos_tier():
    # Replicate the function from app.py
    def get_hos_tier(hours):
        if hours > 24:  return "GREEN"
        if hours > 12:  return "TEAL"
        if hours > 6:   return "AMBER"
        if hours > 2:   return "RED"
        return "PURPLE"
    
    # Test cases
    assert get_hos_tier(30) == "GREEN", "Should return GREEN for 30 hours"
    assert get_hos_tier(15) == "TEAL", "Should return TEAL for 15 hours"
    assert get_hos_tier(8) == "AMBER", "Should return AMBER for 8 hours"
    assert get_hos_tier(3) == "RED", "Should return RED for 3 hours"
    assert get_hos_tier(1) == "PURPLE", "Should return PURPLE for 1 hour"
    return "All HoS tier calculations correct"

test_function("HoS Tier Classification", test_get_hos_tier)

print()
print("2. DATA LOADING & VALIDATION (from trainmodel.py)")
print("-" * 80)

# Test loading training data
def test_load_training_data():
    df = pd.read_csv("training_data (1).csv")
    assert len(df) > 0, "Dataset should not be empty"
    assert "consumption_rate" in df.columns, "Missing 'consumption_rate' column"
    return f"Loaded {len(df)} rows with {len(df.columns)} columns"

test_function("Load Training Data", test_load_training_data)

# Test train/test split logic
def test_train_test_split():
    from sklearn.model_selection import train_test_split
    
    df = pd.read_csv("training_data (1).csv")
    X = df.drop(columns=["consumption_rate"])
    y = df["consumption_rate"]
    
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    
    assert len(X_train) + len(X_test) == len(df), "Split size mismatch"
    assert len(X_train) > len(X_test), "Train set should be larger than test"
    return f"Train: {len(X_train)}, Test: {len(X_test)}"

test_function("Train/Test Split Logic", test_train_test_split)

print()
print("3. MODEL LOADING (from app.py)")
print("-" * 80)

# Test model loading
def test_model_loading():
    import joblib
    model = joblib.load("model.pkl")
    assert model is not None, "Model failed to load"
    # Check if model has predict method
    assert hasattr(model, 'predict'), "Model missing predict method"
    return f"Model loaded successfully, type: {type(model).__name__}"

test_function("Load XGBoost Model", test_model_loading)

print()
print("4. DICTIONARY & MAPPING VALIDATION (from app.py)")
print("-" * 80)

# Test item encoding
def test_item_encoding():
    ITEM_ENC = {
        "ITM001":0,  "ITM002":1,  "ITM003":2,  "ITM004":3,  "ITM005":4,
        "ITM006":5,  "ITM007":6,  "ITM008":7,  "ITM009":8,  "ITM010":9,
        "ITM011":10, "ITM012":11, "ITM013":12, "ITM014":13, "ITM015":14,
        "ITM016":15, "ITM017":16, "ITM018":17, "ITM019":18, "ITM020":19,
    }
    assert len(ITEM_ENC) == 20, "Should have 20 items"
    assert all(isinstance(v, int) for v in ITEM_ENC.values()), "All values should be integers"
    assert ITEM_ENC["ITM001"] == 0 and ITEM_ENC["ITM020"] == 19, "Encoding range incorrect"
    return f"All 20 items properly encoded (0-19)"

test_function("Item Encoding Map", test_item_encoding)

# Test base rates
def test_base_rates():
    BASE_RATES = {
        "ITM001": 4.17,  "ITM002": 2.08,  "ITM003": 2.08,  "ITM004": 10.42,
        "ITM005": 10.42, "ITM006": 10.42, "ITM007": 1.25,  "ITM008": 10.42,
        "ITM009": 10.42, "ITM010": 10.42, "ITM011": 1.25,  "ITM012": 20.83,
        "ITM013": 20.83, "ITM014": 4.17,  "ITM015": 2.08,  "ITM016": 2.08,
        "ITM017": 10.42, "ITM018": 2.78,  "ITM019": 3.47,  "ITM020": 2.78,
    }
    assert len(BASE_RATES) == 20, "Should have 20 items"
    assert all(isinstance(v, float) for v in BASE_RATES.values()), "All values should be floats"
    assert all(v > 0 for v in BASE_RATES.values()), "All rates should be positive"
    return f"All {len(BASE_RATES)} base rates valid (positive floats)"

test_function("Base Consumption Rates", test_base_rates)

# Test clinical event mapping
def test_clinical_mapping():
    CLINICAL_MAP = {
        "tourniquet_applied":   ("ITM004", 1),
        "chest_seal_applied":   ("ITM005", 1),
        "txa_administered":     ("ITM006", 1),
        "iv_fluid_given":       ("ITM008", 1),
        "iv_cannula_inserted":  ("ITM009", 1),
        "intubation":           ("ITM010", 1),
        "blood_transfusion":    ("ITM007", 1),
        "blood_giving_set":     ("ITM011", 1),
        "morphine_given":       ("ITM001", 1),
        "ketamine_given":       ("ITM002", 1),
        "fentanyl_given":       ("ITM003", 1),
        "quikclot_applied":     ("ITM017", 1),
        "decomp_needle":        ("ITM015", 1),
        "cric_performed":       ("ITM016", 1),
        "burn_dressing":        ("ITM018", 1),
    }
    assert len(CLINICAL_MAP) == 15, "Should map 15 clinical events"
    assert all(isinstance(v, tuple) and len(v) == 2 for v in CLINICAL_MAP.values()), \
        "Each event should map to (item_id, quantity) tuple"
    return f"All {len(CLINICAL_MAP)} clinical events properly mapped"

test_function("Clinical Event Mapping", test_clinical_mapping)

print()
print("5. CSV/DATA STRUCTURE VALIDATION")
print("-" * 80)

# Validate training data structure
def test_training_data_structure():
    df = pd.read_csv("training_data (1).csv")
    required_cols = {"consumption_rate"}
    
    # Check if target column exists
    if "consumption_rate" not in df.columns:
        raise ValueError(f"Missing 'consumption_rate' column. Found: {list(df.columns)}")
    
    # Check data types
    assert pd.api.types.is_numeric_dtype(df["consumption_rate"]), \
        "consumption_rate should be numeric"
    
    # Check for NaN values in critical column
    nan_count = df["consumption_rate"].isna().sum()
    assert nan_count == 0, f"Found {nan_count} NaN values in consumption_rate"
    
    return f"Structure valid: {len(df)} rows, {len(df.columns)} cols, 0 NaN in target"

test_function("Training Data Structure", test_training_data_structure)

print()
print("6. QR CODE GENERATION (from generate_qr_codes.py)")
print("-" * 80)

# Test QR data structure
def test_qr_data_structure():
    import json
    
    items = [
        ("ITM001", "Morphine 10mg/ml",   "Analgesic",   "Role1"),
        ("ITM004", "CAT Tourniquet",     "Haemostasis", "Role1"),
    ]
    
    for item_id, name, category, echelon in items:
        qr_data = json.dumps({
            "item_id":  item_id,
            "name":     name,
            "category": category,
            "echelon":  echelon,
            "system":   "MMLS-AI"
        })
        data = json.loads(qr_data)
        assert data["item_id"] == item_id, "QR data item_id mismatch"
    
    return "QR data structure valid"

test_function("QR Code Data Structure", test_qr_data_structure)

print()
print("7. DATABASE SCHEMA VALIDATION (from seed_database.py)")
print("-" * 80)

# Test document structure
def test_db_document_structure():
    today = datetime.today()
    
    # Replicate document structure from seed_database.py
    doc = {
        "item_id":                   "ITM001",
        "item_name":                 "Morphine 10mg/ml",
        "category":                  "Analgesic",
        "echelon":                   "Role1",
        "controlled_drug":           True,
        "current_stock":             25,
        "initial_stock":             25,
        "alert_threshold":           10,
        "avg_consumption_per_hour":  4.17,
        "expiry_date":               today + timedelta(days=180),
        "pack_type":                 "Role1_Pack",
        "last_updated":              today,
    }
    
    required_fields = {
        "item_id", "item_name", "category", "echelon", "controlled_drug",
        "current_stock", "alert_threshold", "avg_consumption_per_hour",
        "expiry_date", "pack_type", "last_updated"
    }
    
    assert all(field in doc for field in required_fields), "Missing required fields"
    return f"Document has all {len(required_fields)} required fields"

test_function("Database Document Schema", test_db_document_structure)

print()
print("=" * 80)
print("TEST RESULTS SUMMARY")
print("=" * 80)
print(f"Passed: {tests_passed}")
print(f"Failed: {tests_failed}")
print(f"Total:  {tests_passed + tests_failed}")
print()

if tests_failed == 0:
    print("✓ ALL FUNCTION TESTS PASSED")
else:
    print(f"✗ {tests_failed} TEST(S) FAILED")
    print("See details above for error information")

print()
