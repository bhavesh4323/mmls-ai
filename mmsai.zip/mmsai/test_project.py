#!/usr/bin/env python3
"""
Comprehensive test script to identify all errors in the MMSAI project.
"""

import os
import sys

print("=" * 80)
print("MMLS-AI PROJECT VALIDATION REPORT")
print("=" * 80)
print()

# ============================================================================
# 1. FILE EXISTENCE CHECKS
# ============================================================================
print("1. FILE EXISTENCE CHECKS")
print("-" * 80)

required_files = {
    "app.py": "Flask backend API",
    "dashboard.py": "Streamlit dashboard",
    "trainmodel.py": "XGBoost model trainer",
    "check_all.py": "System validation script",
    "generate_qr_codes.py": "QR code generator",
    "seed_database.py": "MongoDB database seeder",
    "resave_model.py": "Model conversion utility",
    "training_data (1).csv": "Training dataset",
    "lstm_model.keras": "LSTM model (keras format)",
}

missing_files = []
for fname, desc in required_files.items():
    exists = os.path.exists(fname)
    status = "✓ FOUND" if exists else "✗ MISSING"
    print(f"  {status:15} {fname:30} ({desc})")
    if not exists:
        missing_files.append(fname)

print()

# ============================================================================
# 2. SYNTAX & IMPORT CHECKS
# ============================================================================
print("2. SYNTAX & IMPORT VALIDATION")
print("-" * 80)

import_errors = []
files_to_check = ["app.py", "dashboard.py", "trainmodel.py", "check_all.py", 
                  "generate_qr_codes.py", "seed_database.py", "resave_model.py"]

for fname in files_to_check:
    if os.path.exists(fname):
        try:
            with open(fname, 'r', encoding='utf-8', errors='ignore') as f:
                code = f.read()
            compile(code, fname, 'exec')
            print(f"  ✓ {fname:30} - Syntax OK")
        except SyntaxError as e:
            print(f"  ✗ {fname:30} - SYNTAX ERROR: {e}")
            import_errors.append((fname, str(e)))
    else:
        print(f"  - {fname:30} - File not found (skipped)")

print()

# ============================================================================
# 3. DEPENDENCIES CHECK
# ============================================================================
print("3. REQUIRED DEPENDENCIES")
print("-" * 80)

required_packages = {
    "flask": "Web framework",
    "pymongo": "MongoDB driver",
    "streamlit": "Dashboard framework",
    "pandas": "Data manipulation",
    "numpy": "Numerical computing",
    "plotly": "Interactive charts",
    "joblib": "Model serialization",
    "sklearn": "Machine learning (scikit-learn)",
    "xgboost": "XGBoost library",
    "qrcode": "QR code generator",
    "matplotlib": "Visualization",
    "requests": "HTTP requests",
}

missing_packages = []
for pkg_name, desc in required_packages.items():
    try:
        __import__(pkg_name)
        print(f"  ✓ {pkg_name:20} - {desc}")
    except ImportError:
        print(f"  ✗ {pkg_name:20} - {desc} [NOT INSTALLED]")
        missing_packages.append(pkg_name)

print()

# ============================================================================
# 4. LOGIC & CONFIGURATION CHECKS
# ============================================================================
print("4. LOGIC & CONFIGURATION CHECKS")
print("-" * 80)

logic_errors = []

# Check if trainmodel.py has correct dataset reference
try:
    with open("trainmodel.py", 'r', encoding='utf-8', errors='ignore') as f:
        trainmodel_content = f.read()
except:
    trainmodel_content = ""
if 'training_data (1).csv' in trainmodel_content:
    print("  ✓ trainmodel.py references 'training_data (1).csv'")
    if os.path.exists('training_data (1).csv'):
        print("    ✓ File found")
    else:
        print("    ✗ File NOT found (trainmodel.py will fail)")
        logic_errors.append("training_data (1).csv not found - trainmodel.py will fail")

# Check if app.py can load model.pkl at startup
try:
    with open("app.py", 'r', encoding='utf-8', errors='ignore') as f:
        app_content = f.read()
except:
    app_content = ""
if 'joblib.load("model.pkl")' in app_content:
    if not os.path.exists('model.pkl'):
        print("  ✗ app.py tries to load 'model.pkl' at startup (NOT FOUND)")
        logic_errors.append("model.pkl missing - app.py will crash on import")
    else:
        print("  ✓ model.pkl found")

# Check MongoDB connection assumptions
print("  ℹ app.py connects to MongoDB at 'mongodb://localhost:27017/'")
print("    (MongoDB server must be running for app.py to work)")

# Check if dashboard.py requires app.py to be running
print("  ℹ dashboard.py requires Flask API running at 'http://localhost:5000'")

print()

# ============================================================================
# 5. MISSING FILE ANALYSIS
# ============================================================================
if missing_files:
    print("5. MISSING FILES IMPACT")
    print("-" * 80)
    for fname in missing_files:
        if fname == "training_data (1).csv":
            print(f"  ✗ {fname}")
            print("    → trainmodel.py WILL FAIL: Cannot load dataset for model training")
            print("    → model.pkl will not be generated")
            print("    → app.py will crash when trying to load non-existent model.pkl")
        elif fname == "lstm_model.keras":
            print(f"  ℹ {fname}")
            print("    → Some features may fail if LSTM predictions are used")
    print()

# ============================================================================
# 6. CONFIGURATION ERRORS
# ============================================================================
print("6. SPECIFIC CODE ISSUES FOUND")
print("-" * 80)

# Check for typo in start script  
print("  ℹ Context shows: 'streamlit run dasboard.py' (missing 'h')")
print("    → Should be: 'streamlit run dashboard.py'")

# Check QR code path in dashboard.py
try:
    with open("dashboard.py", 'r', encoding='utf-8', errors='ignore') as f:
        dashboard_content = f.read()
        if 'qr_codes/' in dashboard_content:
            print("  ✓ dashboard.py references qr_codes/ folder (exists)")
except:
    pass

print()

# ============================================================================
# 7. DEPENDENCY INSTALLATION STATUS
# ============================================================================
if missing_packages:
    print("7. REQUIRED PACKAGE INSTALLATIONS")
    print("-" * 80)
    print("  Install missing packages with:")
    print(f"  pip install {' '.join(missing_packages)}")
    print()

# ============================================================================
# 8. SUMMARY
# ============================================================================
print("=" * 80)
print("SUMMARY")
print("=" * 80)

total_issues = len(missing_files) + len(import_errors) + len(missing_packages) + len(logic_errors)
severity = "CRITICAL" if total_issues > 5 else "HIGH" if total_issues > 2 else "MEDIUM" if total_issues > 0 else "OK"

print()
print(f"Severity Level: {severity}")
print(f"Total Issues Found: {total_issues}")
print()

if logic_errors:
    print("CRITICAL ISSUES (will cause runtime failures):")
    for err in logic_errors:
        print(f"  • {err}")
    print()

if missing_packages:
    print(f"MISSING DEPENDENCIES ({len(missing_packages)}):")
    for pkg in missing_packages:
        print(f"  • {pkg}")
    print()

if missing_files:
    print(f"MISSING FILES ({len(missing_files)}):")
    for fname in missing_files:
        print(f"  • {fname}")
    print()

print("NEXT STEPS:")
print("  1. Install missing packages (if any)")
print("  2. Generate training data or obtain 'training_data (1).csv'")
print("  3. Run 'python trainmodel.py' to create model.pkl")
print("  4. Ensure MongoDB is running")
print("  5. Run 'python seed_database.py' to initialize database")
print("  6. Run 'python app.py' to start Flask API (in separate terminal)")
print("  7. Run 'streamlit run dashboard.py' to start dashboard")
print()
print("=" * 80)
