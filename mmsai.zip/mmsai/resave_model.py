import joblib
import xgboost as xgb
import os
p='model.pkl'
if not os.path.exists(p):
    print('model.pkl not found')
else:
    m=joblib.load(p)
    try:
        booster=None
        if hasattr(m,'get_booster'):
            booster=m.get_booster()
        elif isinstance(m, xgb.Booster):
            booster=m
        elif hasattr(m,'booster_'):
            booster=m.booster_
        if booster is not None:
            booster.save_model('model_resaved.json')
            print('Saved XGBoost model as model_resaved.json')
        else:
            joblib.dump(m,'model_resaved.pkl')
            print('Could not locate Booster; re-saved with joblib as model_resaved.pkl')
    except Exception as e:
        print('ERROR:', e)
